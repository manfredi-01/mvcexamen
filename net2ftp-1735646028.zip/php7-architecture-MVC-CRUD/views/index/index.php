<section class="panel">
    <h1>Hola mundo</h1>
    <p>Desde indexController -> index()</p>
</section>